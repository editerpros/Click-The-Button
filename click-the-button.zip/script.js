const startScreen = document.getElementById('startScreen');
const gameUI = document.getElementById('gameUI');
const gameOver = document.getElementById('gameOver');
const scoreClassic = document.getElementById('scoreClassic');
const duelArea = document.getElementById('duelArea');
const finalClassic = document.getElementById('finalClassic');
const finalDuel = document.getElementById('finalDuel');

const clickButton = document.getElementById('clickButton');
const clickP1 = document.getElementById('clickP1');
const clickP2 = document.getElementById('clickP2');

const scoreDisplay = document.getElementById('score');
const scoreP1Display = document.getElementById('scoreP1');
const scoreP2Display = document.getElementById('scoreP2');
const finalScore = document.getElementById('finalScore');

const startBtn = document.getElementById('startGameBtn');
const restartBtn = document.getElementById('restartBtn');
const modeSelect = document.getElementById('mode');
const countdownEl = document.getElementById('countdown');
const timerBar = document.getElementById('timerBar');
const themeSwitch = document.getElementById('themeSwitch');

// Stats
const totalClicksEl = document.getElementById('totalClicks');
const bestScoreEl = document.getElementById('bestScore');
const longestSessionEl = document.getElementById('longestSession');

let score = 0, scoreP1 = 0, scoreP2 = 0;
let timer, duration = 10, countdown, startTime;
let currentMode = "classic";

function updateStats(sessionScore, sessionTime) {
  let total = +localStorage.getItem('totalClicks') || 0;
  let best = +localStorage.getItem('bestScore') || 0;
  let longest = +localStorage.getItem('longestSession') || 0;

  total += sessionScore;
  best = Math.max(best, sessionScore);
  longest = Math.max(longest, sessionTime);

  localStorage.setItem('totalClicks', total);
  localStorage.setItem('bestScore', best);
  localStorage.setItem('longestSession', longest);

  totalClicksEl.textContent = total;
  bestScoreEl.textContent = best;
  longestSessionEl.textContent = longest;
}

function showGameOver() {
  clearInterval(timer);
  gameUI.classList.add('hidden');
  gameOver.classList.remove('hidden');

  const sessionTime = Math.floor((Date.now() - startTime) / 1000);

  if (currentMode === "classic") {
    finalClassic.classList.remove('hidden');
    finalScore.textContent = score;
    updateStats(score, sessionTime);
    confetti();
  } else {
    finalDuel.classList.remove('hidden');
    const winner = scoreP1 > scoreP2 ? 'Player 1 Wins!' : scoreP2 > scoreP1 ? 'Player 2 Wins!' : 'It\'s a Draw!';
    finalDuel.innerHTML = `<h2>${winner}</h2><p>P1: ${scoreP1} | P2: ${scoreP2}</p>`;
    updateStats(scoreP1 + scoreP2, sessionTime);
    confetti();
  }
}

function startGame() {
  startScreen.classList.add('hidden');
  gameUI.classList.remove('hidden');
  gameOver.classList.add('hidden');
  finalClassic.classList.add('hidden');
  finalDuel.classList.add('hidden');
  score = scoreP1 = scoreP2 = 0;
  scoreDisplay.textContent = '0';
  scoreP1Display.textContent = '0';
  scoreP2Display.textContent = '0';

  currentMode = modeSelect.value;
  if (currentMode === 'classic') {
    scoreClassic.classList.remove('hidden');
    duelArea.classList.add('hidden');
  } else {
    scoreClassic.classList.add('hidden');
    duelArea.classList.remove('hidden');
  }

  countdownEl.textContent = "3";
  let count = 3;
  countdown = setInterval(() => {
    count--;
    countdownEl.textContent = count;
    if (count === 0) {
      clearInterval(countdown);
      countdownEl.classList.add('hidden');
      startTimer();
    }
  }, 1000);
}

function startTimer() {
  score = scoreP1 = scoreP2 = 0;
  scoreDisplay.textContent = score;
  scoreP1Display.textContent = scoreP1;
  scoreP2Display.textContent = scoreP2;

  startTime = Date.now();
  let timeLeft = duration;
  timerBar.style.width = "100%";

  timer = setInterval(() => {
    timeLeft--;
    timerBar.style.width = `${(timeLeft / duration) * 100}%`;
    if (timeLeft <= 0) {
      clearInterval(timer);
      showGameOver();
    }
  }, 1000);
}

clickButton.addEventListener('click', () => {
  score++;
  scoreDisplay.textContent = score;
  clickButton.classList.add('clicked');
  setTimeout(() => clickButton.classList.remove('clicked'), 100);
});

clickP1.addEventListener('click', () => {
  scoreP1++;
  scoreP1Display.textContent = scoreP1;
});

clickP2.addEventListener('click', () => {
  scoreP2++;
  scoreP2Display.textContent = scoreP2;
});

startBtn.addEventListener('click', startGame);

restartBtn.addEventListener('click', () => {
  startScreen.classList.remove('hidden');
  gameUI.classList.add('hidden');
  gameOver.classList.add('hidden');
});

themeSwitch.addEventListener('change', () => {
  document.body.classList.toggle('dark-mode');
});

// Initialize stats
window.onload = () => {
  totalClicksEl.textContent = localStorage.getItem('totalClicks') || 0;
  bestScoreEl.textContent = localStorage.getItem('bestScore') || 0;
  longestSessionEl.textContent = localStorage.getItem('longestSession') || 0;
};
